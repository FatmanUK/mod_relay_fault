# Sample set — Phase Lock

Status: provisional analytical selection from the actual supplied archives. Sample audition takes place after composition, as requested. The source bytes are not edited.

These are headerless raw sample files, interpreted provisionally as signed 8-bit mono PCM. There is no stored playback rate, note, finetune or loop metadata in these files. Confirm interpretation in the compiled import. All instrument finetunes are `00`; no pitch correction is silently applied.

| ID | Source | Role | Bytes (hex) | Peak | RMS quarters | DC | Rails % | Default volume |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | ST-01/BassDrum2 | kick | 0BB8 | 127 | 41.20 / 29.45 / 6.64 / 2.51 | 0.98 | 0.00 | `38` |
| 02 | ST-01/PopSnare1 | snare | 07D0 | 127 | 77.96 / 49.84 / 20.06 / 5.26 | 0.30 | 1.10 | `2A` |
| 03 | ST-01/HiHat2 | hat | 07D0 | 127 | 46.24 / 25.92 / 9.80 / 4.96 | 0.74 | 0.05 | `22` |
| 04 | ST-01/KorgBass | bass | 0FA0 | 88 | 32.92 / 21.36 / 12.42 / 6.41 | 0.14 | 0.00 | `3A` |
| 05 | ST-01/Leader | lead | 0D48 | 127 | 48.66 / 29.97 / 12.41 / 2.00 | -0.04 | 0.03 | `25` |
| 06 | ST-01/KorgFilter | stab | 0D48 | 86 | 22.33 / 26.26 / 25.01 / 24.31 | -0.06 | 0.00 | `1C` |
| 07 | ST-01/SynClaves | tick | 03E8 | 127 | 46.12 / 11.81 / 4.26 / 1.51 | -0.16 | 0.10 | `20` |
| 08 | ST-02/Cymbal2 | cymbal | 0CE4 | 128 | 68.83 / 40.59 / 10.75 / 3.39 | -0.25 | 1.55 | `1D` |
| 09 | ST-02/SynBuz | answer | 0E74 | 112 | 44.98 / 28.68 / 9.71 / 3.51 | -2.85 | 0.00 | `23` |

Signal measurements use decimal sample units; a signed sample lies from -128 to +127. RMS quarters are chronological, equal-duration portions of the unchanged file. Rail percentage counts samples exactly at -128 or +127; it is evidence of saturation risk, not proof of audible clipping. Volumes and IDs are hexadecimal.

- `01` ST-01/BassDrum2: Clean declining low body; main weight.
- `02` ST-01/PopSnare1: Dry, clearly decaying backbeat.
- `03` ST-01/HiHat2: Finite noisy top with a shorter tail than HiHat1.
- `04` ST-01/KorgBass: Moderate peak and steadily falling body; raised register is unnecessary beyond its mapped pulses.
- `05` ST-01/Leader: Short melodic calls; natural decay leaves a reply gap.
- `06` ST-01/KorgFilter: Bright finite phase marker; no sustain loop needed.
- `07` ST-01/SynClaves: A single mechanical click, always C-4.
- `08` ST-02/Cymbal2: Only the broadest arrivals need this tail.
- `09` ST-02/SynBuz: Low native voice raised to answer the Leader.

## Suitability, register and balance

Every pitched part is a single monophonic line; there are no chord samples or arpeggiator effects. Pitched sample spectra are broadly consistent with C-related harmonic material; this is provisional suitability evidence, not a by-ear confirmation that every source is an ideal single note. Inharmonic bells and attack noise should not be mistaken for deliberately layered chords.

Default volumes balance source RMS, peak and role. Percussion with large peaks is attenuated; the quiet CloseHiHat, when selected, uses its full source level. Per-row accents remain explicit in the tables. A lower default cannot undo clipping already present in source audio.

DXBass was excluded because its source has a very large DC offset. CowBell was excluded from these sets because of substantial rail occupancy and DC. Where a saturated kick/snare is selected, its grit is a deliberate provisional timbral choice and is identified above. No reverse or ping-pong behaviour is used.

All selected envelopes are used as finite events. No sustained pad role is required; see `loops.md` for loopability decisions and the KorgFilter seam diagnostic. The exact written pitch subsets and provisional source-root estimates are in `ranges.md`.

## Sample audition criteria — after composition

- Solo each instrument at every actual trigger pitch in `ranges.md`, using its metadata volume first. Confirm signed PCM interpretation, note identity, register, attack quality and tail behaviour.
- Compare bass and main voice on the same named tonic and fifth; allow their planned octave separation, then listen for unintended detuning or beating. Keep finetune zero unless the brief is explicitly changed.
- Check the pitched samples are perceived as single notes. If a source sounds like a fixed chord, report that source and exact trigger; do not approve it merely because the spectrum looked harmonic.
- Check low sample endings and every gate for clicks. Evaluate noisy percussion tails at both normal and quiet monitoring levels. Check deliberately saturated sources for useful grit versus objectionable harshness.
- Check kick/bass balance, main-voice intelligibility and hat/tick audibility in the complete ensemble and in mono. Compare the initial group with the densest group before deciding defaults.
- Preserve accepted by-ear sample volumes, loop changes, finetune and row edits in the actual auditioned project. Return that exact project with notes so the source can be reconciled.

Piece-specific check: Check that the late lead entries feel intentional. The D-sharp error must resolve clearly back to D, and the final convergence must feel tighter than the opening.
