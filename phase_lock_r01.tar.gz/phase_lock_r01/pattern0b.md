# Pattern 0b — Clocks converge

Group D; harmonic bars: Dm, Dm, Dm, Dm. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half recalls a; the second half is the independently written capture edge coda.

Ch1 kick/snare; Ch2 KorgBass; Ch3 Leader with selected SynBuz replies; Ch4 filter stabs, hats and ticks.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
F00 requests playback stop on row 63. The final hit is followed by a fixed silence boundary, not a volume fade. Stop handling remains a required check in the compiled MOD and the user’s MilkyTracker replay mode.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | D-4 04 --- | --- -- C00 | D-3 06 C1C |
| 01 | --- -- --- | --- -- --- | D-4 05 C25 | --- -- --- |
| 03 | --- -- --- | D-4 04 --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 05 | --- -- --- | --- -- --- | F-4 05 C21 | --- -- --- |
| 06 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 07 | --- -- --- | A-4 04 EC4 | --- -- --- | --- -- --- |
| 08 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 09 | --- -- --- | --- -- --- | A-4 05 C25 | --- -- --- |
| 10 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 11 | --- -- --- | F-4 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 14 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C20 |
| 16 | C-4 01 C38 | D-4 04 --- | --- -- --- | --- -- --- |
| 17 | --- -- --- | --- -- --- | G-4 05 C21 | --- -- --- |
| 18 | --- -- --- | D-4 04 --- | --- -- --- | C-4 03 C22 |
| 19 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 21 | --- -- --- | --- -- --- | E-4 05 C25 | --- -- --- |
| 22 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 24 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 25 | --- -- --- | D-5 04 --- | D-4 05 C21 | --- -- --- |
| 26 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C22 |
| 27 | --- -- --- | F-4 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 30 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 31 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 07 C20 |
| 32 | C-4 01 C38 | D-4 04 EC4 | F-4 05 C25 | --- -- --- |
| 35 | --- -- --- | --- -- --- | E-4 05 C20 | C-4 07 C20 |
| 38 | C-4 02 C2A | A-4 04 EC4 | D-4 05 C25 | --- -- --- |
| 41 | --- -- --- | --- -- --- | A-3 05 C20 | C-4 07 C20 |
| 44 | C-4 02 C2A | D-5 04 EC4 | C-4 05 C25 | --- -- --- |
| 46 | --- -- --- | --- -- --- | E-4 05 C20 | C-4 07 C18 |
| 48 | C-4 02 C2A | A-4 04 EC4 | D-4 05 C25 | --- -- --- |
| 50 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C20 |
| 52 | C-4 01 C38 | D-4 04 --- | D-4 05 C25 | C-4 08 C1D |
| 56 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C18 |
| 60 | --- -- C00 | --- -- C00 | --- -- C00 | --- -- C00 |
| 63 | --- -- F00 | --- -- --- | --- -- --- | --- -- --- |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check that the late lead entries feel intentional. The D-sharp error must resolve clearly back to D, and the final convergence must feel tighter than the opening.
- Check the last full group flows into the distinct flourish, the root landing is convincing, and the final cut does not steal a needed tail. Verify F00 stops, all channels are silent, and pattern00 does not restart.
