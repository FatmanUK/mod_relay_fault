# Structural arc and motifs — Phase Lock

Two independent switching clocks gradually find the same downbeat. The pulse is present from the first row; altered replies create the development.

A establishes the two clocks over D and C. B opens onto B-flat and C before D reasserts itself. C tests the lock with a D-sharp neighbour and a deliberately displaced answer. A and B return as working states. D narrows G–A–D into a final convergence.

Tonal language: D minor, with a brief D-sharp phase error.

| Motif | Identity |
| --- | --- |
| Clock teeth | Bass attacks on rows 00, 03, 07 and their answers; no walking bass fill. |
| Late acknowledgement | A three-note rising hook answered by a falling D-minor tag after a short rest. |
| Phase flag | Low KorgFilter stabs alternate with dry synthetic ticks rather than a sustained pad. |
| Capture edge | The coda moves from three-row separations to two-row replies before one D impact. |

## Phrase vocabulary

These are authored thirty-two-row melodic fragments. Pattern tables are the build source. A fragment may hand its reply to another sample as described in the pattern notes; each event is still one note. Times below are decimal row offsets.

| Fragment | Events: row / trigger |
| --- | --- |
| a | 01/D-4, 05/F-4, 09/A-4, 17/G-4, 21/E-4, 25/D-4 |
| b | 02/A-3, 06/C-4, 11/D-4, 18/F-4, 23/E-4, 27/D-4 |
| c | 00/F-4, 06/D-4, 10/C-4, 18/D-4, 22/F-4, 27/A-4 |
| d | 03/A-4, 07/G-4, 11/E-4, 19/D-4, 24/C-4, 28/D-4 |
| e | 01/D-4, 04/F-4, 07/A-4, 11/G-4, 18/D-4, 22/E-4, 26/F-4 |
| f | 02/D#4, 06/F#4, 10/A#4, 18/G#4, 22/F#4, 26/D#4 |
| g | 00/G-4, 06/F-4, 10/D-4, 18/C-4, 22/A-3, 28/D-4 |
| h | 01/E-4, 05/C#4, 10/A-3, 18/C#4, 23/E-4, 27/D-4 |

The named motif is developed by changing which fragment answers it, the underlying bass state, and the percussion handoffs. The first group begins with the complete working ensemble. Repeated groups return at full identity; there is no default empty breakdown and gradual rebuild. The terminal group is used once, and its coda has separately authored events.
