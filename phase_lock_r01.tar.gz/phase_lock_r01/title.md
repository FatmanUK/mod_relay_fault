# Title selection — Phase Lock

Ten candidates; selected by the composer for this independent draft. No title choice implies an audition result.

| Candidate | Direction |
| --- | --- |
| Phase Lock | Two independent switching clocks gradually find the same downbeat. The pulse is present from the first row; altered replies create the development. |
| Skew Register | A narrow mechanical operation under pressure. |
| Sync Window | A stable state with an unsettling implied fault. |
| Clock Drift | A terse instruction with audible rhythmic implications. |
| Delay Line | An enclosed technical environment. |
| Edge Trigger | A timing relationship capable of driving a motif. |
| Pulse Domain | A compact name for a persistent operating condition. |
| Hold Time | A limit approached without a conventional breakdown. |
| Signal Aperture | A signal whose state can be heard changing. |
| Duty Cycle | A hard-edged technical phrase suited to a decisive coda. |

## Winner: Phase Lock

Tight interlocking electro: the bass occupies the gaps around a dry answer, while the top line repeatedly arrives a little later than expected.

Two independent switching clocks gradually find the same downbeat. The pulse is present from the first row; altered replies create the development.
