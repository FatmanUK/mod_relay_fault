# Pattern 08 — Capture maintained

Group C; harmonic bars: Dm, Dm, Dm, Dm. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses e; second half uses d. In the second half, SynBuz takes the answer one trigger octave above the Leader labels to compensate its lower source register.

Ch1 kick/snare; Ch2 KorgBass; Ch3 Leader with selected SynBuz replies; Ch4 filter stabs, hats and ticks.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | D-4 04 --- | --- -- C00 | C-4 08 C1D |
| 01 | --- -- --- | --- -- --- | D-4 05 C25 | --- -- --- |
| 03 | --- -- --- | D-4 04 --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C2A | --- -- --- | F-4 05 C21 | --- -- --- |
| 06 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 07 | --- -- --- | A-4 04 EC4 | A-4 05 C25 | --- -- --- |
| 08 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 10 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 11 | --- -- --- | F-4 04 --- | G-4 05 C21 | --- -- --- |
| 12 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 14 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C20 |
| 16 | C-4 01 C38 | D-4 04 --- | --- -- --- | --- -- --- |
| 18 | --- -- --- | D-4 04 --- | D-4 05 C25 | C-4 03 C22 |
| 19 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 22 | --- -- --- | A-4 04 EC4 | E-4 05 C21 | C-4 03 C22 |
| 24 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 25 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 26 | --- -- --- | --- -- --- | F-4 05 C25 | C-4 03 C22 |
| 27 | --- -- --- | F-4 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 30 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 31 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 07 C20 |
| 32 | C-4 01 C38 | D-4 04 --- | --- -- --- | D-3 06 C1C |
| 35 | --- -- --- | D-4 04 --- | A-5 09 C23 | --- -- --- |
| 36 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 38 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 39 | --- -- --- | A-4 04 EC4 | G-5 09 C1F | --- -- --- |
| 40 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 42 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 43 | --- -- --- | F-4 04 --- | E-5 09 C23 | --- -- --- |
| 44 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 46 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 47 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C20 |
| 48 | C-4 01 C38 | D-4 04 --- | --- -- --- | --- -- --- |
| 50 | --- -- --- | D-4 04 --- | --- -- --- | C-4 03 C22 |
| 51 | C-4 01 C32 | --- -- --- | D-5 09 C1F | --- -- --- |
| 52 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 54 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 56 | C-4 01 C38 | --- -- --- | C-5 09 C23 | --- -- --- |
| 57 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 58 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C22 |
| 59 | --- -- --- | F-4 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C2A | --- -- --- | D-5 09 C1F | --- -- --- |
| 62 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 63 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 07 C20 |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check that the late lead entries feel intentional. The D-sharp error must resolve clearly back to D, and the final convergence must feel tighter than the opening.
