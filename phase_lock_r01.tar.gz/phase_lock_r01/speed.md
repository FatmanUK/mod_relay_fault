# Speed and tempo — Phase Lock

| Setting | Value |
| --- | --- |
| Initial speed | `06` ticks per row |
| Initial BPM | `8A` hex = 138 decimal |
| Full pattern duration | 6.956522 seconds |
| Order positions | `24` |
| Nominal full-order duration | 250.435 seconds |

Tight interlocking electro: the bass occupies the gaps around a dry answer, while the top line repeatedly arrives a little later than expected.

The tempo is a new composition decision for this piece. CIA-style timing is assumed for the calculation: row duration = speed × 2.5 / BPM. Initial Fxx commands match `song.yaml`. There are no later tempo changes, row delays or pattern breaks. F00 on the last row can shorten the final row according to replay handling; measured duration remains pending.

The six-tick grid allows both sustained body and short tick-four gates without relying on XM envelopes.
