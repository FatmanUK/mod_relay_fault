# Pattern plan — Phase Lock

Group membership is exclusive; each group contains at most four patterns. Patterns were written sequentially, group by group, beginning with pattern00.

| Group | Pattern members | Role |
| --- | --- | --- |
| A | 00 01 02 | First complete working state |
| B | 03 04 05 | Alternate working / pressure state |
| C | 06 07 08 | Alternate working / pressure state |
| D | 09 0a 0b | One-time terminal route and coda |

Group order: **A B A C B C A B C B C D**.

A establishes the two clocks over D and C. B opens onto B-flat and C before D reasserts itself. C tests the lock with a D-sharp neighbour and a deliberately displaced answer. A and B return as working states. D narrows G–A–D into a final convergence.

| Pattern | Harmonic bars | Fragments | Purpose |
| --- | --- | --- | --- |
| 00 | Dm, Dm, Dm, Dm | a / b | Clock pair established |
| 01 | Dm, Dm, Dm, Dm | b / a | Reply clock exposed |
| 02 | C, C, C, C | c / d | Shared phase moves down |
| 03 | A#, A#, A#, A# | c / b | Window opens |
| 04 | C, C, C, C | d / c | Window returns |
| 05 | Dm, Dm, Dm, Dm | a / d | Lock holds |
| 06 | Dm, Dm, Dm, Dm | e / a | Phase pressure |
| 07 | D#m, D#m, Dm, Dm | f / e | One semitone error |
| 08 | Dm, Dm, Dm, Dm | e / d | Capture maintained |
| 09 | Gm, Gm, Gm, Gm | g / c | Convergence begins |
| 0a | A, A, A, A | h / d | Capture window narrows |
| 0b | Dm, Dm, Dm, Dm | a / independent coda | Clocks converge |

| Order position (hex) | Pattern |
| --- | --- |
| 00 | 00 |
| 01 | 01 |
| 02 | 02 |
| 03 | 03 |
| 04 | 04 |
| 05 | 05 |
| 06 | 00 |
| 07 | 01 |
| 08 | 02 |
| 09 | 06 |
| 0A | 07 |
| 0B | 08 |
| 0C | 03 |
| 0D | 04 |
| 0E | 05 |
| 0F | 06 |
| 10 | 07 |
| 11 | 08 |
| 12 | 00 |
| 13 | 01 |
| 14 | 02 |
| 15 | 03 |
| 16 | 04 |
| 17 | 05 |
| 18 | 06 |
| 19 | 07 |
| 1A | 08 |
| 1B | 03 |
| 1C | 04 |
| 1D | 05 |
| 1E | 06 |
| 1F | 07 |
| 20 | 08 |
| 21 | 09 |
| 22 | 0a |
| 23 | 0b |

Nominal duration is 250.435 seconds before terminal-row stop nuances. Standard MOD size estimate is 39,172 bytes, including 25,800 raw sample bytes and twelve pattern blocks. These are calculations, not compiled measurements.

All patterns have 64 logical rows. Omitted table rows are entirely empty rows; the compiler must expand them. There are no Dxx breaks, Bxx order jumps, E6x musical loops or tempo changes. Order-list reuse, rather than flow-control effects, creates the structure. The last pattern contains an articulated final flourish and F00. Player stop handling is pending validation.
