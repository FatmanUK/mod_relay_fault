# Pattern 07 — One semitone error

Group C; harmonic bars: D#m, D#m, Dm, Dm. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses f; second half uses e.

Ch1 kick/snare; Ch2 KorgBass; Ch3 Leader with selected SynBuz replies; Ch4 filter stabs, hats and ticks.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | D#4 04 --- | --- -- C00 | D#3 06 C1C |
| 02 | --- -- --- | D#4 04 --- | D#4 05 C25 | --- -- --- |
| 03 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 06 | --- -- --- | A#4 04 EC4 | F#4 05 C21 | C-4 03 C22 |
| 08 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 09 | --- -- --- | D#5 04 --- | --- -- --- | --- -- --- |
| 10 | --- -- --- | --- -- --- | A#4 05 C25 | C-4 03 C22 |
| 11 | --- -- --- | F#4 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 14 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 15 | --- -- --- | A#4 04 EC4 | --- -- --- | C-4 07 C20 |
| 16 | C-4 01 C38 | D#4 04 --- | --- -- --- | --- -- --- |
| 18 | --- -- --- | --- -- --- | G#4 05 C21 | C-4 03 C22 |
| 19 | --- -- --- | A#4 04 --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 22 | C-4 01 C32 | --- -- --- | F#4 05 C25 | C-4 03 C22 |
| 23 | --- -- --- | D#5 04 EC4 | --- -- --- | --- -- --- |
| 24 | --- -- --- | F#4 04 --- | --- -- --- | --- -- --- |
| 26 | C-4 01 C32 | --- -- --- | D#4 05 C21 | C-4 03 C22 |
| 27 | --- -- --- | A#4 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 30 | --- -- --- | D#4 04 EC4 | --- -- --- | C-4 03 C22 |
| 31 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C20 |
| 32 | C-4 01 C38 | D-4 04 --- | --- -- --- | D-3 06 C1C |
| 33 | --- -- --- | --- -- --- | D-4 05 C25 | --- -- --- |
| 34 | --- -- --- | D-4 04 --- | --- -- --- | --- -- --- |
| 35 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 36 | C-4 02 C2A | --- -- --- | F-4 05 C21 | --- -- --- |
| 38 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 39 | --- -- --- | --- -- --- | A-4 05 C25 | --- -- --- |
| 40 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 41 | --- -- --- | D-5 04 --- | --- -- --- | --- -- --- |
| 42 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C22 |
| 43 | --- -- --- | F-4 04 --- | G-4 05 C21 | --- -- --- |
| 44 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 46 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C22 |
| 47 | --- -- --- | A-4 04 EC4 | --- -- --- | C-4 07 C20 |
| 48 | C-4 01 C38 | D-4 04 --- | --- -- --- | --- -- --- |
| 50 | --- -- --- | --- -- --- | D-4 05 C25 | C-4 03 C22 |
| 51 | --- -- --- | A-4 04 --- | --- -- --- | --- -- --- |
| 52 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 54 | C-4 01 C32 | --- -- --- | E-4 05 C21 | C-4 03 C22 |
| 55 | --- -- --- | D-5 04 EC4 | --- -- --- | --- -- --- |
| 56 | --- -- --- | F-4 04 --- | --- -- --- | --- -- --- |
| 58 | C-4 01 C32 | --- -- --- | F-4 05 C25 | C-4 03 C22 |
| 59 | --- -- --- | A-4 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C2A | --- -- --- | --- -- --- | --- -- --- |
| 62 | --- -- --- | D-4 04 EC4 | --- -- --- | C-4 03 C22 |
| 63 | C-4 02 C20 | --- -- --- | --- -- --- | C-4 07 C20 |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check that the late lead entries feel intentional. The D-sharp error must resolve clearly back to D, and the final convergence must feel tighter than the opening.
