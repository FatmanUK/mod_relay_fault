# Pattern 0a — Decision held

Group C; harmonic bars: G#m, G#m, C#m, C#m. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses h; second half uses e. Leader answers in Ch4 on alternating bars; hats resume after the answer window.

Ch1 kick/snare; Ch2 FunkBass; Ch3 clipped MuteClav bites; Ch4 hats, dry ticks and longer Leader replies.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | G#5 04 --- | G#4 05 C24 | --- -- C00 |
| 02 | --- -- --- | B-5 04 EC4 | --- -- --- | C-4 03 C1D |
| 03 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 05 | --- -- --- | D#5 04 EC4 | --- -- --- | C-4 03 ED1 |
| 06 | --- -- --- | --- -- --- | F#4 05 EC4 | --- -- --- |
| 08 | C-4 01 C38 | G#5 04 EC4 | --- -- --- | --- -- --- |
| 10 | --- -- --- | --- -- --- | D#4 05 C24 | C-4 03 C1D |
| 11 | --- -- --- | G#5 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 14 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 15 | --- -- --- | D#5 04 EC4 | --- -- --- | C-4 07 C16 |
| 16 | C-4 01 C38 | G#5 04 --- | --- -- --- | --- -- --- |
| 17 | --- -- --- | --- -- --- | --- -- --- | D#4 06 C23 |
| 18 | --- -- --- | --- -- --- | B-3 05 C20 | --- -- --- |
| 19 | --- -- --- | B-5 04 EC4 | --- -- --- | --- -- --- |
| 20 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 22 | C-4 01 C32 | D#5 04 EC4 | --- -- --- | G#4 06 C23 |
| 24 | C-4 01 C38 | --- -- --- | G#3 05 EC4 | --- -- --- |
| 25 | --- -- --- | G#5 04 EC4 | --- -- --- | --- -- --- |
| 27 | C-4 01 C32 | G#5 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C31 | --- -- --- | C#4 05 C20 | C-4 03 C1D |
| 30 | --- -- --- | D#5 04 EC4 | --- -- --- | C-4 03 C1D |
| 31 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 32 | C-4 01 C38 | C#5 04 --- | C#4 05 C24 | --- -- --- |
| 34 | --- -- --- | E-5 04 EC4 | E-4 05 EC4 | C-4 03 C1D |
| 35 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 36 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 37 | --- -- --- | G#5 04 EC4 | --- -- --- | C-4 03 ED1 |
| 40 | C-4 01 C38 | C#5 04 EC4 | G#4 05 C24 | --- -- --- |
| 42 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 43 | --- -- --- | C#5 04 --- | --- -- --- | --- -- --- |
| 44 | C-4 02 C31 | --- -- --- | E-4 05 C20 | --- -- --- |
| 45 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 46 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 47 | --- -- --- | G#5 04 EC4 | --- -- --- | C-4 07 C16 |
| 48 | C-4 01 C38 | C#5 04 --- | --- -- --- | --- -- --- |
| 49 | --- -- --- | --- -- --- | --- -- --- | G#4 06 C23 |
| 51 | --- -- --- | E-5 04 EC4 | D#4 05 EC4 | --- -- --- |
| 52 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 54 | C-4 01 C32 | G#5 04 EC4 | --- -- --- | C#4 06 C23 |
| 56 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 57 | --- -- --- | C#5 04 EC4 | C#4 05 C20 | --- -- --- |
| 59 | C-4 01 C32 | C#5 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C31 | --- -- --- | --- -- --- | C-4 03 C1D |
| 62 | --- -- --- | G#5 04 EC4 | --- -- --- | C-4 03 C1D |
| 63 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 07 C16 |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check MuteClav is heard as one note, and that its clipped bites plus the slower Leader answer form one phrase. The bass should propel the toggle without masking the pluck. The closing clicks must sound final rather than like the next loop starting.
