# Pattern 0b — Latch clicks shut

Group C; harmonic bars: C#m, C#m, C#m, C#m. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half recalls a; the second half is the independently written latch closure coda. Leader answers in Ch4 on alternating bars; hats resume after the answer window.

Ch1 kick/snare; Ch2 FunkBass; Ch3 clipped MuteClav bites; Ch4 hats, dry ticks and longer Leader replies.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.
F00 requests playback stop on row 63. The final hit is followed by a fixed silence boundary, not a volume fade. Stop handling remains a required check in the compiled MOD and the user’s MilkyTracker replay mode.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | C#5 04 --- | C#4 05 C24 | --- -- C00 |
| 02 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 03 | --- -- --- | E-5 04 EC4 | E-4 05 EC4 | --- -- --- |
| 04 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 05 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 06 | C-4 01 C32 | G#5 04 EC4 | --- -- --- | --- -- --- |
| 08 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 09 | --- -- --- | C#5 04 EC4 | --- -- --- | --- -- --- |
| 10 | --- -- --- | --- -- --- | G#4 05 C24 | C-4 03 C1D |
| 11 | C-4 01 C32 | C#5 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 14 | --- -- --- | G#5 04 EC4 | --- -- --- | --- -- --- |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 16 | C-4 01 C38 | C#5 04 --- | --- -- --- | --- -- --- |
| 17 | --- -- --- | --- -- --- | --- -- --- | G#4 06 C23 |
| 18 | --- -- --- | E-5 04 EC4 | F#4 05 C20 | --- -- --- |
| 19 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 21 | --- -- --- | G#5 04 EC4 | --- -- --- | --- -- --- |
| 22 | --- -- --- | --- -- --- | --- -- --- | C#4 06 C23 |
| 23 | --- -- --- | --- -- --- | E-4 05 EC4 | --- -- --- |
| 24 | C-4 01 C38 | C#5 04 EC4 | --- -- --- | --- -- --- |
| 27 | --- -- --- | C#5 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C31 | --- -- --- | C#4 05 C20 | C-4 03 C1D |
| 30 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C1D |
| 31 | --- -- --- | G#5 04 EC4 | --- -- --- | C-4 07 C16 |
| 32 | C-4 01 C38 | C#5 04 EC4 | --- -- --- | --- -- --- |
| 34 | --- -- --- | --- -- --- | E-4 05 C24 | --- -- --- |
| 36 | C-4 02 C20 | --- -- --- | --- -- --- | --- -- --- |
| 38 | --- -- --- | G#5 04 EC4 | --- -- --- | C-4 07 C1D |
| 40 | --- -- --- | --- -- --- | D#4 06 C23 | --- -- --- |
| 42 | --- -- --- | B-5 04 EC4 | --- -- --- | --- -- --- |
| 44 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 46 | --- -- --- | --- -- --- | C#4 05 C24 | --- -- --- |
| 48 | --- -- --- | G#5 04 EC4 | --- -- --- | --- -- --- |
| 50 | --- -- --- | --- -- --- | C#4 06 C23 | --- -- --- |
| 54 | C-4 01 C38 | C#5 04 --- | C#4 05 C24 | C-4 08 C1A |
| 57 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C22 |
| 59 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C1D |
| 61 | --- -- C00 | --- -- C00 | --- -- C00 | --- -- C00 |
| 63 | --- -- F00 | --- -- --- | --- -- --- | --- -- --- |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check MuteClav is heard as one note, and that its clipped bites plus the slower Leader answer form one phrase. The bass should propel the toggle without masking the pluck. The closing clicks must sound final rather than like the next loop starting.
- Check the last full group flows into the distinct flourish, the root landing is convincing, and the final cut does not steal a needed tail. Verify F00 stops, all channels are silent, and pattern00 does not restart.
