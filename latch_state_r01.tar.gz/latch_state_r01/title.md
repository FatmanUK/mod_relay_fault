# Title selection — Latch State

Ten candidates; selected by the composer for this independent draft. No title choice implies an audition result.

| Candidate | Direction |
| --- | --- |
| Latch State | A latch refuses to settle. Its repeated toggle is musically stable, but each response changes the apparent state until a final pair of dry clicks closes it. |
| Toggle Hold | A narrow mechanical operation under pressure. |
| Sticky Bit | A stable state with an unsettling implied fault. |
| State Register | A terse instruction with audible rhythmic implications. |
| Set Reset | An enclosed technical environment. |
| Contact Memory | A timing relationship capable of driving a motif. |
| Hysteresis | A compact name for a persistent operating condition. |
| Gate Hold | A limit approached without a conventional breakdown. |
| Seal Logic | A signal whose state can be heard changing. |
| Retentive | A hard-edged technical phrase suited to a decisive coda. |

## Winner: Latch State

A clipped clavinet mechanism with low, syncopated bass and separate Leader responses; firm industrial drums keep it from becoming light funk.

A latch refuses to settle. Its repeated toggle is musically stable, but each response changes the apparent state until a final pair of dry clicks closes it.
