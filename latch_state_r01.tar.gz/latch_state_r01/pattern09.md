# Pattern 09 — Latch approaches

Group C; harmonic bars: B, B, B, B. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses c; second half uses f. Leader answers in Ch4 on alternating bars; hats resume after the answer window.

Ch1 kick/snare; Ch2 FunkBass; Ch3 clipped MuteClav bites; Ch4 hats, dry ticks and longer Leader replies.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | B-5 04 --- | B-3 05 C24 | --- -- C00 |
| 02 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 03 | --- -- --- | D#5 04 EC4 | --- -- --- | --- -- --- |
| 04 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 05 | --- -- --- | --- -- --- | D#4 05 EC4 | C-4 03 ED1 |
| 06 | C-4 01 C32 | F#5 04 EC4 | --- -- --- | --- -- --- |
| 08 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 09 | --- -- --- | B-5 04 EC4 | --- -- --- | --- -- --- |
| 10 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 11 | C-4 01 C32 | B-5 04 --- | F#4 05 C24 | --- -- --- |
| 12 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 14 | --- -- --- | F#5 04 EC4 | --- -- --- | --- -- --- |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 16 | C-4 01 C38 | B-5 04 --- | --- -- --- | --- -- --- |
| 17 | --- -- --- | --- -- --- | --- -- --- | F#4 06 C23 |
| 18 | --- -- --- | D#5 04 EC4 | E-4 05 C20 | --- -- --- |
| 19 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 21 | --- -- --- | F#5 04 EC4 | --- -- --- | --- -- --- |
| 22 | --- -- --- | --- -- --- | --- -- --- | B-4 06 C23 |
| 24 | C-4 01 C38 | B-5 04 EC4 | D#4 05 EC4 | --- -- --- |
| 27 | --- -- --- | B-5 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C31 | --- -- --- | B-3 05 C20 | C-4 03 C1D |
| 30 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C1D |
| 31 | --- -- --- | F#5 04 EC4 | --- -- --- | C-4 07 C16 |
| 32 | C-4 01 C38 | B-5 04 --- | --- -- --- | --- -- --- |
| 34 | --- -- --- | --- -- --- | E-4 05 C24 | C-4 03 C1D |
| 35 | --- -- --- | D#5 04 EC4 | --- -- --- | --- -- --- |
| 36 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 37 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 38 | C-4 01 C32 | F#5 04 EC4 | F#4 05 EC4 | --- -- --- |
| 40 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 41 | --- -- --- | B-5 04 EC4 | --- -- --- | --- -- --- |
| 42 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 43 | C-4 01 C32 | B-5 04 --- | G#4 05 C24 | --- -- --- |
| 44 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 45 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 46 | --- -- --- | F#5 04 EC4 | --- -- --- | --- -- --- |
| 47 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 48 | C-4 01 C38 | B-5 04 --- | --- -- --- | --- -- --- |
| 49 | --- -- --- | --- -- --- | --- -- --- | F#4 06 C23 |
| 50 | --- -- --- | D#5 04 EC4 | B-3 05 C20 | --- -- --- |
| 51 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 52 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 53 | --- -- --- | F#5 04 EC4 | --- -- --- | --- -- --- |
| 54 | --- -- --- | --- -- --- | --- -- --- | B-4 06 C23 |
| 55 | --- -- --- | --- -- --- | D#4 05 EC4 | --- -- --- |
| 56 | C-4 01 C38 | B-5 04 EC4 | --- -- --- | --- -- --- |
| 59 | --- -- --- | B-5 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C31 | --- -- --- | F#4 05 C20 | C-4 03 C1D |
| 62 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C1D |
| 63 | --- -- --- | F#5 04 EC4 | --- -- --- | C-4 07 C16 |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check MuteClav is heard as one note, and that its clipped bites plus the slower Leader answer form one phrase. The bass should propel the toggle without masking the pluck. The closing clicks must sound final rather than like the next loop starting.
