# Structural arc and motifs — Latch State

A latch refuses to settle. Its repeated toggle is musically stable, but each response changes the apparent state until a final pair of dry clicks closes it.

A is a four-pattern toggle cycle around C-sharp and B. B opens the A–B–C-sharp circuit, using a different Lead/Clav response placement while retaining the motor. Returns deliberately alternate the two established working states. C is a one-time four-pattern closure route, ending with the latch clicking shut.

Tonal language: C-sharp minor with A and B returns.

| Motif | Identity |
| --- | --- |
| Toggle tooth | FunkBass syncopation answered by a short MuteClav two-note bite. |
| Held decision | Leader answers occupy a later phrase window; the channels never require a chord sample. |
| State lamp | Synthetic tick marks and occasional cymbal entries indicate state changes while the drums continue. |
| Latch closure | An interrupted descending answer settles on C-sharp, followed by two dry closing clicks. |

## Phrase vocabulary

These are authored thirty-two-row melodic fragments. Pattern tables are the build source. A fragment may hand its reply to another sample as described in the pattern notes; each event is still one note. Times below are decimal row offsets.

| Fragment | Events: row / trigger |
| --- | --- |
| a | 00/C#4, 03/E-4, 10/G#4, 18/F#4, 23/E-4, 28/C#4 |
| b | 02/G#3, 06/B-3, 12/C#4, 19/E-4, 25/D#4, 29/C#4 |
| c | 00/B-3, 05/D#4, 11/F#4, 18/E-4, 24/D#4, 28/B-3 |
| d | 01/A-3, 05/C#4, 12/E-4, 20/F#4, 26/E-4 |
| e | 00/C#4, 02/E-4, 08/G#4, 12/E-4, 19/D#4, 25/C#4 |
| f | 02/E-4, 06/F#4, 11/G#4, 18/B-3, 23/D#4, 28/F#4 |
| g | 01/F#4, 06/E-4, 12/C#4, 20/A-3, 26/C#4 |
| h | 00/G#4, 06/F#4, 10/D#4, 18/B-3, 24/G#3, 28/C#4 |

The named motif is developed by changing which fragment answers it, the underlying bass state, and the percussion handoffs. The first group begins with the complete working ensemble. Repeated groups return at full identity; there is no default empty breakdown and gradual rebuild. The terminal group is used once, and its coda has separately authored events.
