# Pattern 08 — Closure route

Group C; harmonic bars: F#m, F#m, A, A. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses g; second half uses d. Leader answers in Ch4 on alternating bars; hats resume after the answer window.

Ch1 kick/snare; Ch2 FunkBass; Ch3 clipped MuteClav bites; Ch4 hats, dry ticks and longer Leader replies.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC4 cuts that channel at tick 04 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C38 | F#5 04 --- | --- -- C00 | --- -- C00 |
| 01 | --- -- --- | --- -- --- | F#4 05 C24 | --- -- --- |
| 02 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 03 | --- -- --- | A-5 04 EC4 | --- -- --- | --- -- --- |
| 04 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 05 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 06 | C-4 01 C32 | C#5 04 EC4 | E-4 05 EC4 | --- -- --- |
| 08 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 09 | --- -- --- | F#5 04 EC4 | --- -- --- | --- -- --- |
| 10 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 11 | C-4 01 C32 | F#5 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C31 | --- -- --- | C#4 05 C24 | --- -- --- |
| 13 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 14 | --- -- --- | C#5 04 EC4 | --- -- --- | --- -- --- |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 16 | C-4 01 C38 | F#5 04 --- | --- -- --- | --- -- --- |
| 17 | --- -- --- | --- -- --- | --- -- --- | C#4 06 C23 |
| 18 | --- -- --- | A-5 04 EC4 | --- -- --- | --- -- --- |
| 19 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 20 | C-4 02 C31 | --- -- --- | A-3 05 C20 | --- -- --- |
| 21 | --- -- --- | C#5 04 EC4 | --- -- --- | --- -- --- |
| 22 | --- -- --- | --- -- --- | --- -- --- | F#4 06 C23 |
| 24 | C-4 01 C38 | F#5 04 EC4 | --- -- --- | --- -- --- |
| 26 | --- -- --- | --- -- --- | C#4 05 EC4 | --- -- --- |
| 27 | --- -- --- | F#5 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C31 | --- -- --- | --- -- --- | C-4 03 C1D |
| 30 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C1D |
| 31 | --- -- --- | C#5 04 EC4 | --- -- --- | C-4 07 C16 |
| 32 | C-4 01 C38 | A-5 04 --- | --- -- --- | --- -- --- |
| 33 | --- -- --- | --- -- --- | A-3 05 C24 | --- -- --- |
| 34 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 35 | --- -- --- | C#5 04 EC4 | --- -- --- | --- -- --- |
| 36 | C-4 02 C31 | --- -- --- | --- -- --- | --- -- --- |
| 37 | --- -- --- | --- -- --- | C#4 05 EC4 | C-4 03 ED1 |
| 38 | C-4 01 C32 | E-5 04 EC4 | --- -- --- | --- -- --- |
| 40 | C-4 01 C38 | --- -- --- | --- -- --- | --- -- --- |
| 41 | --- -- --- | A-5 04 EC4 | --- -- --- | --- -- --- |
| 42 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C1D |
| 43 | C-4 01 C32 | A-5 04 --- | --- -- --- | --- -- --- |
| 44 | C-4 02 C31 | --- -- --- | E-4 05 C24 | --- -- --- |
| 45 | --- -- --- | --- -- --- | --- -- --- | C-4 03 ED1 |
| 46 | --- -- --- | E-5 04 EC4 | --- -- --- | --- -- --- |
| 47 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C16 |
| 48 | C-4 01 C38 | A-5 04 --- | --- -- --- | --- -- --- |
| 49 | --- -- --- | --- -- --- | --- -- --- | E-4 06 C23 |
| 50 | --- -- --- | C#5 04 EC4 | --- -- --- | --- -- --- |
| 51 | C-4 01 C32 | --- -- --- | --- -- --- | --- -- --- |
| 52 | C-4 02 C31 | --- -- --- | F#4 05 C20 | --- -- --- |
| 53 | --- -- --- | E-5 04 EC4 | --- -- --- | --- -- --- |
| 54 | --- -- --- | --- -- --- | --- -- --- | A-4 06 C23 |
| 56 | C-4 01 C38 | A-5 04 EC4 | --- -- --- | --- -- --- |
| 58 | --- -- --- | --- -- --- | E-4 05 EC4 | --- -- --- |
| 59 | --- -- --- | A-5 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C31 | --- -- --- | --- -- --- | C-4 03 C1D |
| 62 | C-4 01 C32 | --- -- --- | --- -- --- | C-4 03 C1D |
| 63 | --- -- --- | E-5 04 EC4 | --- -- --- | C-4 07 C16 |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check MuteClav is heard as one note, and that its clipped bites plus the slower Leader answer form one phrase. The bass should propel the toggle without masking the pluck. The closing clicks must sound final rather than like the next loop starting.
