# Sample set — Latch State

Status: provisional analytical selection from the actual supplied archives. Sample audition takes place after composition, as requested. The source bytes are not edited.

These are headerless raw sample files, interpreted provisionally as signed 8-bit mono PCM. There is no stored playback rate, note, finetune or loop metadata in these files. Confirm interpretation in the compiled import. All instrument finetunes are `00`; no pitch correction is silently applied.

| ID | Source | Role | Bytes (hex) | Peak | RMS quarters | DC | Rails % | Default volume |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | ST-01/BassDrum2 | kick | 0BB8 | 127 | 41.20 / 29.45 / 6.64 / 2.51 | 0.98 | 0.00 | `38` |
| 02 | ST-01/Snare3 | snare | 0ED8 | 128 | 54.34 / 12.17 / 8.94 / 9.38 | 0.73 | 0.05 | `31` |
| 03 | ST-01/HiHat1 | hat | 0578 | 127 | 54.07 / 39.32 / 33.51 / 20.99 | -0.18 | 0.43 | `1D` |
| 04 | ST-01/FunkBass | bass | 14B4 | 81 | 26.82 / 19.91 / 17.31 / 9.23 | -0.10 | 0.00 | `3C` |
| 05 | ST-01/MuteClav | lead | 13EC | 127 | 53.32 / 19.20 / 6.82 / 2.46 | -0.02 | 0.12 | `24` |
| 06 | ST-01/Leader | stab | 0D48 | 127 | 48.66 / 29.97 / 12.41 / 2.00 | -0.04 | 0.03 | `23` |
| 07 | ST-01/SynClaves | tick | 03E8 | 127 | 46.12 / 11.81 / 4.26 / 1.51 | -0.16 | 0.10 | `1D` |
| 08 | ST-02/Cymbal2 | cymbal | 0CE4 | 128 | 68.83 / 40.59 / 10.75 / 3.39 | -0.25 | 1.55 | `1A` |

Signal measurements use decimal sample units; a signed sample lies from -128 to +127. RMS quarters are chronological, equal-duration portions of the unchanged file. Rail percentage counts samples exactly at -128 or +127; it is evidence of saturation risk, not proof of audible clipping. Volumes and IDs are hexadecimal.

- `01` ST-01/BassDrum2: Firm but relatively clean low pulse.
- `02` ST-01/Snare3: Short main body followed by a low noisy tail; inspect its cutoffs.
- `03` ST-01/HiHat1: Longer noisy hat body supports short delayed offbeats at a restrained level.
- `04` ST-01/FunkBass: Low recorded voice with a persistent body, raised to octave five and deliberately gated.
- `05` ST-01/MuteClav: Fast-decaying harmonic pluck for clipped bites.
- `06` ST-01/Leader: Here the secondary voice is a melodic answer, not a filter stab.
- `07` ST-01/SynClaves: A dry closure click with a finite body.
- `08` ST-02/Cymbal2: Occasional wider impact; not a constant ride.

## Suitability, register and balance

Every pitched part is a single monophonic line; there are no chord samples or arpeggiator effects. Pitched sample spectra are broadly consistent with C-related harmonic material; this is provisional suitability evidence, not a by-ear confirmation that every source is an ideal single note. Inharmonic bells and attack noise should not be mistaken for deliberately layered chords.

Default volumes balance source RMS, peak and role. Percussion with large peaks is attenuated; the quiet CloseHiHat, when selected, uses its full source level. Per-row accents remain explicit in the tables. A lower default cannot undo clipping already present in source audio.

DXBass was excluded because its source has a very large DC offset. CowBell was excluded from these sets because of substantial rail occupancy and DC. Where a saturated kick/snare is selected, its grit is a deliberate provisional timbral choice and is identified above. No reverse or ping-pong behaviour is used.

All selected envelopes are used as finite events. No sustained pad role is required; see `loops.md` for loopability decisions and the KorgFilter seam diagnostic. The exact written pitch subsets and provisional source-root estimates are in `ranges.md`.

## Sample audition criteria — after composition

- Solo each instrument at every actual trigger pitch in `ranges.md`, using its metadata volume first. Confirm signed PCM interpretation, note identity, register, attack quality and tail behaviour.
- Compare bass and main voice on the same named tonic and fifth; allow their planned octave separation, then listen for unintended detuning or beating. Keep finetune zero unless the brief is explicitly changed.
- Check the pitched samples are perceived as single notes. If a source sounds like a fixed chord, report that source and exact trigger; do not approve it merely because the spectrum looked harmonic.
- Check low sample endings and every gate for clicks. Evaluate noisy percussion tails at both normal and quiet monitoring levels. Check deliberately saturated sources for useful grit versus objectionable harshness.
- Check kick/bass balance, main-voice intelligibility and hat/tick audibility in the complete ensemble and in mono. Compare the initial group with the densest group before deciding defaults.
- Preserve accepted by-ear sample volumes, loop changes, finetune and row edits in the actual auditioned project. Return that exact project with notes so the source can be reconciled.

Piece-specific check: Check MuteClav is heard as one note, and that its clipped bites plus the slower Leader answer form one phrase. The bass should propel the toggle without masking the pluck. The closing clicks must sound final rather than like the next loop starting.
