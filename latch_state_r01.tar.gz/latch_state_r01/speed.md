# Speed and tempo — Latch State

| Setting | Value |
| --- | --- |
| Initial speed | `06` ticks per row |
| Initial BPM | `7E` hex = 126 decimal |
| Full pattern duration | 7.619048 seconds |
| Order positions | `20` |
| Nominal full-order duration | 243.810 seconds |

A clipped clavinet mechanism with low, syncopated bass and separate Leader responses; firm industrial drums keep it from becoming light funk.

The tempo is a new composition decision for this piece. CIA-style timing is assumed for the calculation: row duration = speed × 2.5 / BPM. Initial Fxx commands match `song.yaml`. There are no later tempo changes, row delays or pattern breaks. F00 on the last row can shorten the final row according to replay handling; measured duration remains pending.

The six-tick grid allows both sustained body and short tick-four gates without relying on XM envelopes.
