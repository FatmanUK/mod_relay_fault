# Pattern plan — Latch State

Group membership is exclusive; each group contains at most four patterns. Patterns were written sequentially, group by group, beginning with pattern00.

| Group | Pattern members | Role |
| --- | --- | --- |
| A | 00 01 02 03 | First complete working state |
| B | 04 05 06 07 | Alternate working / pressure state |
| C | 08 09 0a 0b | One-time terminal route and coda |

Group order: **A B A B A B B C**.

A is a four-pattern toggle cycle around C-sharp and B. B opens the A–B–C-sharp circuit, using a different Lead/Clav response placement while retaining the motor. Returns deliberately alternate the two established working states. C is a one-time four-pattern closure route, ending with the latch clicking shut.

| Pattern | Harmonic bars | Fragments | Purpose |
| --- | --- | --- | --- |
| 00 | C#m, C#m, C#m, C#m | a / b | Toggle identity |
| 01 | C#m, C#m, C#m, C#m | b / a | Held reply |
| 02 | B, B, B, B | c / b | State appears reversed |
| 03 | C#m, C#m, C#m, C#m | e / a | Latch returns |
| 04 | A, A, A, A | d / f | Alternate contact |
| 05 | B, B, B, B | c / f | Other state |
| 06 | C#m, C#m, C#m, C#m | e / b | Contact under load |
| 07 | G#m, G#m, C#m, C#m | h / a | Toggle resolves |
| 08 | F#m, F#m, A, A | g / d | Closure route |
| 09 | B, B, B, B | c / f | Latch approaches |
| 0a | G#m, G#m, C#m, C#m | h / e | Decision held |
| 0b | C#m, C#m, C#m, C#m | a / independent coda | Latch clicks shut |

| Order position (hex) | Pattern |
| --- | --- |
| 00 | 00 |
| 01 | 01 |
| 02 | 02 |
| 03 | 03 |
| 04 | 04 |
| 05 | 05 |
| 06 | 06 |
| 07 | 07 |
| 08 | 00 |
| 09 | 01 |
| 0A | 02 |
| 0B | 03 |
| 0C | 04 |
| 0D | 05 |
| 0E | 06 |
| 0F | 07 |
| 10 | 00 |
| 11 | 01 |
| 12 | 02 |
| 13 | 03 |
| 14 | 04 |
| 15 | 05 |
| 16 | 06 |
| 17 | 07 |
| 18 | 04 |
| 19 | 05 |
| 1A | 06 |
| 1B | 07 |
| 1C | 08 |
| 1D | 09 |
| 1E | 0a |
| 1F | 0b |

Nominal duration is 243.810 seconds before terminal-row stop nuances. Standard MOD size estimate is 39,672 bytes, including 26,300 raw sample bytes and twelve pattern blocks. These are calculations, not compiled measurements.

All patterns have 64 logical rows. Omitted table rows are entirely empty rows; the compiler must expand them. There are no Dxx breaks, Bxx order jumps, E6x musical loops or tempo changes. Order-list reuse, rather than flow-control effects, creates the structure. The last pattern contains an articulated final flourish and F00. Player stop handling is pending validation.
