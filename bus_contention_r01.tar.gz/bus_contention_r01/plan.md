# Pattern plan — Bus Contention

Group membership is exclusive; each group contains at most four patterns. Patterns were written sequentially, group by group, beginning with pattern00.

| Group | Pattern members | Role |
| --- | --- | --- |
| A | 00 01 02 03 | First complete working state |
| B | 04 05 06 07 | Alternate working / pressure state |
| C | 08 09 0a 0b | One-time terminal route and coda |

Group order: **A B A B B A B A C**.

A establishes four competing packet phrases without an empty intro. B expands the conflict through D and E before F-sharp wins a local return. Reordered A and B blocks make the same packets feel argumentative. C is a final four-pattern arbitration, ending with alternating channel claims and a unified final strike.

| Pattern | Harmonic bars | Fragments | Purpose |
| --- | --- | --- | --- |
| 00 | F#m, F#m, F#m, F#m | a / b | First packet exchange |
| 01 | F#m, F#m, F#m, F#m | b / a | Competing request |
| 02 | C#m, C#m, C#m, C#m | f / b | Priority changes |
| 03 | F#m, F#m, F#m, F#m | e / h | Local allocation |
| 04 | D, D, E, E | c / d | Network contention |
| 05 | E, E, D, D | d / c | Queue reverses |
| 06 | F#m, F#m, F#m, F#m | g / e | Burst saturation |
| 07 | C#m, C#m, F#m, F#m | f / h | Local winner |
| 08 | D, D, D, D | c / g | Arbitration opens |
| 09 | E, E, C#m, C#m | d / f | Requests serialise |
| 0a | F#m, F#m, F#m, F#m | e / h | Grant prepared |
| 0b | F#m, F#m, F#m, F#m | a / independent coda | Bus grant |

| Order position (hex) | Pattern |
| --- | --- |
| 00 | 00 |
| 01 | 01 |
| 02 | 02 |
| 03 | 03 |
| 04 | 04 |
| 05 | 05 |
| 06 | 06 |
| 07 | 07 |
| 08 | 00 |
| 09 | 01 |
| 0A | 02 |
| 0B | 03 |
| 0C | 04 |
| 0D | 05 |
| 0E | 06 |
| 0F | 07 |
| 10 | 04 |
| 11 | 05 |
| 12 | 06 |
| 13 | 07 |
| 14 | 00 |
| 15 | 01 |
| 16 | 02 |
| 17 | 03 |
| 18 | 04 |
| 19 | 05 |
| 1A | 06 |
| 1B | 07 |
| 1C | 00 |
| 1D | 01 |
| 1E | 02 |
| 1F | 03 |
| 20 | 08 |
| 21 | 09 |
| 22 | 0a |
| 23 | 0b |

Nominal duration is 240.000 seconds before terminal-row stop nuances. Standard MOD size estimate is 38,572 bytes, including 25,200 raw sample bytes and twelve pattern blocks. These are calculations, not compiled measurements.

All patterns have 64 logical rows. Omitted table rows are entirely empty rows; the compiler must expand them. There are no Dxx breaks, Bxx order jumps, E6x musical loops or tempo changes. Order-list reuse, rather than flow-control effects, creates the structure. The last pattern contains an articulated final flourish and F00. Player stop handling is pending validation.
