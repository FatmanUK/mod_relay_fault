# Title selection — Bus Contention

Ten candidates; selected by the composer for this independent draft. No title choice implies an audition result.

| Candidate | Direction |
| --- | --- |
| Bus Contention | Several machines demand the same bus. Their calls collide in rhythm, a stable allocation returns, and a final arbitration grants one unambiguous F-sharp. |
| Packet Storm | A narrow mechanical operation under pressure. |
| Write Collision | A stable state with an unsettling implied fault. |
| Arbitration | A terse instruction with audible rhythmic implications. |
| Queue Depth | An enclosed technical environment. |
| Race Window | A timing relationship capable of driving a motif. |
| Port Conflict | A compact name for a persistent operating condition. |
| Data Hazard | A limit approached without a conventional breakdown. |
| Busy Flag | A signal whose state can be heard changing. |
| Lock Request | A hard-edged technical phrase suited to a decisive coda. |

## Winner: Bus Contention

Fast, combative electro with a five-tick grid, terse bass packets and replies competing across the stereo field.

Several machines demand the same bus. Their calls collide in rhythm, a stable allocation returns, and a final arbitration grants one unambiguous F-sharp.
