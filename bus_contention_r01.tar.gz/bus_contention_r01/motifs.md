# Structural arc and motifs — Bus Contention

Several machines demand the same bus. Their calls collide in rhythm, a stable allocation returns, and a final arbitration grants one unambiguous F-sharp.

A establishes four competing packet phrases without an empty intro. B expands the conflict through D and E before F-sharp wins a local return. Reordered A and B blocks make the same packets feel argumentative. C is a final four-pattern arbitration, ending with alternating channel claims and a unified final strike.

Tonal language: F-sharp minor, moving through D and E.

| Motif | Identity |
| --- | --- |
| Packet burst | Fast TechBass figures use a root, fifth and minor-third packet with a deliberate empty reply slot. |
| Competing request | Leader fragments start on a different row from the bass and give way to a filter claim. |
| Priority tick | Blubzing and SynClaves act as unpitched control marks; some hats are delayed one tick. |
| Bus grant | The coda alternates channel claims before a single common final F-sharp. |

## Phrase vocabulary

These are authored thirty-two-row melodic fragments. Pattern tables are the build source. A fragment may hand its reply to another sample as described in the pattern notes; each event is still one note. Times below are decimal row offsets.

| Fragment | Events: row / trigger |
| --- | --- |
| a | 00/F#4, 03/A-4, 07/G#4, 11/F#4, 18/E-4, 22/C#4, 27/F#4 |
| b | 02/C#4, 05/E-4, 10/F#4, 17/A-3, 21/B-3, 26/C#4 |
| c | 01/D-4, 04/F#4, 08/A-4, 13/G#4, 19/F#4, 24/E-4, 28/D-4 |
| d | 02/E-4, 06/G#4, 10/B-3, 18/C#4, 22/G#4, 27/E-4 |
| e | 00/F#4, 02/A-4, 05/G#4, 09/F#4, 12/E-4, 18/C#4, 23/E-4, 27/F#4 |
| f | 01/C#4, 04/E-4, 08/G#4, 13/F#4, 19/E-4, 25/C#4 |
| g | 00/A-4, 05/G#4, 10/F#4, 18/E-4, 23/C#4, 28/A-3 |
| h | 02/F#4, 07/E-4, 11/C#4, 18/B-3, 23/C#4, 27/F#4 |

The named motif is developed by changing which fragment answers it, the underlying bass state, and the percussion handoffs. The first group begins with the complete working ensemble. Repeated groups return at full identity; there is no default empty breakdown and gradual rebuild. The terminal group is used once, and its coda has separately authored events.
