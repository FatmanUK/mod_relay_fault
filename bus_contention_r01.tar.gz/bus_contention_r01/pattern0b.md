# Pattern 0b — Bus grant

Group C; harmonic bars: F#m, F#m, F#m, F#m. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half recalls a; the second half is the independently written bus grant coda.

Ch1 kick/snare packets; Ch2 TechBass; Ch3 Leader claims; Ch4 filter, delayed hats and alternating control chirps.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC3 cuts that channel at tick 03 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.
F00 requests playback stop on row 63. The final hit is followed by a fixed silence boundary, not a volume fade. Stop handling remains a required check in the compiled MOD and the user’s MilkyTracker replay mode.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C28 | F#4 04 --- | F#4 05 C24 | F#3 06 C20 |
| 02 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 03 | C-4 01 C22 | --- -- --- | A-4 05 EC3 | --- -- --- |
| 04 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 03 C38 |
| 05 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 06 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 07 | --- -- --- | --- -- --- | G#4 05 C24 | --- -- --- |
| 08 | C-4 01 C28 | A-4 04 EC3 | --- -- --- | --- -- --- |
| 10 | --- -- --- | C#5 04 --- | --- -- --- | C-4 03 ED1 |
| 11 | C-4 01 C22 | --- -- --- | F#4 05 C20 | --- -- --- |
| 12 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | F#5 04 EC3 | --- -- --- | --- -- --- |
| 14 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 15 | --- -- --- | F#4 04 --- | --- -- --- | C-4 07 C22 |
| 16 | C-4 01 C28 | F#4 04 --- | --- -- --- | --- -- --- |
| 18 | C-4 01 C22 | --- -- --- | E-4 05 EC3 | C-4 03 ED1 |
| 19 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 20 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 22 | --- -- --- | F#4 04 EC3 | C#4 05 C20 | C-4 03 C40 |
| 24 | C-4 01 C28 | A-4 04 EC3 | --- -- --- | --- -- --- |
| 26 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 27 | --- -- --- | C#5 04 --- | F#4 05 C24 | --- -- --- |
| 28 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 30 | --- -- --- | F#5 04 EC3 | --- -- --- | C-4 03 C40 |
| 31 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 32 | C-4 01 C28 | --- -- --- | --- -- --- | --- -- --- |
| 33 | --- -- --- | --- -- --- | F#4 05 EC3 | --- -- --- |
| 34 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 35 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 37 | C-4 01 C28 | --- -- --- | --- -- --- | --- -- --- |
| 38 | --- -- --- | --- -- --- | E-4 05 EC3 | --- -- --- |
| 39 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 40 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C22 |
| 42 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 43 | --- -- --- | --- -- --- | C#4 05 EC3 | --- -- --- |
| 44 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 45 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 47 | C-4 07 C22 | --- -- --- | --- -- --- | --- -- --- |
| 48 | --- -- --- | --- -- --- | A-3 05 EC3 | --- -- --- |
| 49 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 50 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 52 | C-4 01 C28 | F#4 04 --- | F#4 05 C24 | C-4 08 C1C |
| 60 | --- -- C00 | --- -- C00 | --- -- C00 | --- -- C00 |
| 63 | --- -- F00 | --- -- --- | --- -- --- | --- -- --- |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check the five-tick articulation, especially one-tick hat delays: it should sound deliberate, not like misplaced notes. Audition the saturated kick and snare quietly as well as at normal level.
- Check the last full group flows into the distinct flourish, the root landing is convincing, and the final cut does not steal a needed tail. Verify F00 stops, all channels are silent, and pattern00 does not restart.
