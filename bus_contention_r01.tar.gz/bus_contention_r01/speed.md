# Speed and tempo — Bus Contention

| Setting | Value |
| --- | --- |
| Initial speed | `05` ticks per row |
| Initial BPM | `78` hex = 120 decimal |
| Full pattern duration | 6.666667 seconds |
| Order positions | `24` |
| Nominal full-order duration | 240.000 seconds |

Fast, combative electro with a five-tick grid, terse bass packets and replies competing across the stereo field.

The tempo is a new composition decision for this piece. CIA-style timing is assumed for the calculation: row duration = speed × 2.5 / BPM. Initial Fxx commands match `song.yaml`. There are no later tempo changes, row delays or pattern breaks. F00 on the last row can shorten the final row according to replay handling; measured duration remains pending.

At speed 05, four-row beats occur at an effective 150 per minute even though the tracker BPM is 120. The five-tick grid makes EC3 a useful short gate and ED1 a small offbeat displacement.
