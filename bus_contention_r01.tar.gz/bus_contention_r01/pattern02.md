# Pattern 02 — Priority changes

Group A; harmonic bars: C#m, C#m, C#m, C#m. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses f; second half uses b.

Ch1 kick/snare packets; Ch2 TechBass; Ch3 Leader claims; Ch4 filter, delayed hats and alternating control chirps.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC3 cuts that channel at tick 03 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C28 | C#4 04 --- | --- -- C00 | C#3 06 C20 |
| 01 | --- -- --- | --- -- --- | C#4 05 C24 | --- -- --- |
| 02 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 03 | --- -- --- | G#4 04 EC3 | --- -- --- | --- -- --- |
| 04 | C-4 02 C27 | --- -- --- | E-4 05 EC3 | C-4 03 C38 |
| 06 | --- -- --- | C#4 04 EC3 | --- -- --- | C-4 03 C40 |
| 08 | C-4 01 C28 | E-4 04 EC3 | G#4 05 C24 | --- -- --- |
| 10 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 11 | --- -- --- | G#4 04 --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | --- -- --- | F#4 05 C20 | --- -- --- |
| 14 | --- -- --- | C#5 04 EC3 | --- -- --- | C-4 03 C40 |
| 15 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C22 |
| 16 | C-4 01 C28 | C#4 04 --- | --- -- --- | --- -- --- |
| 18 | --- -- --- | G#4 04 EC3 | --- -- --- | C-4 03 ED1 |
| 19 | C-4 01 C22 | --- -- --- | E-4 05 EC3 | --- -- --- |
| 20 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 21 | --- -- --- | C#4 04 EC3 | --- -- --- | --- -- --- |
| 22 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 24 | C-4 01 C28 | E-4 04 EC3 | --- -- --- | --- -- --- |
| 25 | --- -- --- | --- -- --- | C#4 05 C20 | --- -- --- |
| 26 | --- -- --- | G#4 04 --- | --- -- --- | C-4 03 ED1 |
| 27 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 29 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 30 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 31 | --- -- --- | C#4 04 --- | --- -- --- | C-4 09 C1C |
| 32 | C-4 01 C28 | C#4 04 --- | --- -- --- | C#3 06 C20 |
| 34 | C-4 01 C22 | --- -- --- | C#4 05 C24 | --- -- --- |
| 35 | --- -- --- | G#4 04 EC3 | --- -- --- | --- -- --- |
| 36 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 03 C38 |
| 37 | --- -- --- | --- -- --- | E-4 05 EC3 | --- -- --- |
| 38 | --- -- --- | C#4 04 EC3 | --- -- --- | C-4 03 C40 |
| 40 | C-4 01 C28 | E-4 04 EC3 | --- -- --- | --- -- --- |
| 42 | C-4 01 C22 | --- -- --- | F#4 05 C24 | C-4 03 ED1 |
| 43 | --- -- --- | G#4 04 --- | --- -- --- | --- -- --- |
| 44 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 46 | --- -- --- | C#5 04 EC3 | --- -- --- | C-4 03 C40 |
| 47 | --- -- --- | --- -- --- | --- -- --- | C-4 07 C22 |
| 48 | C-4 01 C28 | C#4 04 --- | --- -- --- | --- -- --- |
| 49 | --- -- --- | --- -- --- | A-3 05 C20 | --- -- --- |
| 50 | --- -- --- | G#4 04 EC3 | --- -- --- | C-4 03 ED1 |
| 51 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 52 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 53 | --- -- --- | C#4 04 EC3 | B-3 05 EC3 | --- -- --- |
| 54 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 56 | C-4 01 C28 | E-4 04 EC3 | --- -- --- | --- -- --- |
| 58 | --- -- --- | G#4 04 --- | C#4 05 C20 | C-4 03 ED1 |
| 59 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 61 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 62 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 63 | --- -- --- | C#4 04 --- | --- -- --- | C-4 09 C1C |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check the five-tick articulation, especially one-tick hat delays: it should sound deliberate, not like misplaced notes. Audition the saturated kick and snare quietly as well as at normal level.
