# Pattern 06 — Burst saturation

Group B; harmonic bars: F#m, F#m, F#m, F#m. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses g; second half uses e.

Ch1 kick/snare packets; Ch2 TechBass; Ch3 Leader claims; Ch4 filter, delayed hats and alternating control chirps.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC3 cuts that channel at tick 03 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C28 | F#4 04 --- | A-4 05 C24 | F#3 06 C20 |
| 02 | --- -- --- | C#5 04 EC3 | --- -- --- | --- -- --- |
| 03 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 03 C38 |
| 05 | --- -- --- | F#4 04 EC3 | G#4 05 EC3 | --- -- --- |
| 06 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 08 | C-4 01 C28 | A-4 04 EC3 | --- -- --- | --- -- --- |
| 10 | --- -- --- | C#5 04 --- | F#4 05 C24 | C-4 03 ED1 |
| 11 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | F#5 04 EC3 | --- -- --- | --- -- --- |
| 14 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 15 | --- -- --- | F#4 04 --- | --- -- --- | C-4 07 C22 |
| 16 | C-4 01 C28 | C#5 04 --- | --- -- --- | --- -- --- |
| 18 | C-4 01 C22 | --- -- --- | E-4 05 C20 | C-4 03 ED1 |
| 19 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 20 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 22 | --- -- --- | A-4 04 EC3 | --- -- --- | C-4 03 C40 |
| 23 | --- -- --- | --- -- --- | C#4 05 EC3 | --- -- --- |
| 24 | C-4 01 C28 | C#5 04 EC3 | --- -- --- | --- -- --- |
| 26 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 27 | --- -- --- | F#5 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C27 | --- -- --- | A-3 05 C20 | --- -- --- |
| 30 | --- -- --- | F#4 04 EC3 | --- -- --- | C-4 03 C40 |
| 31 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 32 | C-4 01 C28 | F#4 04 --- | F#4 05 C24 | F#3 06 C20 |
| 34 | --- -- --- | C#5 04 EC3 | A-4 05 EC3 | --- -- --- |
| 35 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 36 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 03 C38 |
| 37 | --- -- --- | F#4 04 EC3 | G#4 05 C24 | --- -- --- |
| 38 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 40 | C-4 01 C28 | A-4 04 EC3 | --- -- --- | --- -- --- |
| 41 | --- -- --- | --- -- --- | F#4 05 C20 | --- -- --- |
| 42 | --- -- --- | C#5 04 --- | --- -- --- | C-4 03 ED1 |
| 43 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 44 | C-4 02 C27 | --- -- --- | E-4 05 EC3 | --- -- --- |
| 45 | --- -- --- | F#5 04 EC3 | --- -- --- | --- -- --- |
| 46 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 47 | --- -- --- | F#4 04 --- | --- -- --- | C-4 07 C22 |
| 48 | C-4 01 C28 | C#5 04 --- | --- -- --- | --- -- --- |
| 50 | C-4 01 C22 | --- -- --- | C#4 05 C20 | C-4 03 ED1 |
| 51 | --- -- --- | F#4 04 EC3 | --- -- --- | --- -- --- |
| 52 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 54 | --- -- --- | A-4 04 EC3 | --- -- --- | C-4 03 C40 |
| 55 | --- -- --- | --- -- --- | E-4 05 C24 | --- -- --- |
| 56 | C-4 01 C28 | C#5 04 EC3 | --- -- --- | --- -- --- |
| 58 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 59 | --- -- --- | F#5 04 --- | F#4 05 EC3 | --- -- --- |
| 60 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 62 | --- -- --- | F#4 04 EC3 | --- -- --- | C-4 03 C40 |
| 63 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check the five-tick articulation, especially one-tick hat delays: it should sound deliberate, not like misplaced notes. Audition the saturated kick and snare quietly as well as at normal level.
