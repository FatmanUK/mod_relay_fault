# Pattern 08 — Arbitration opens

Group C; harmonic bars: D, D, D, D. Logical length: 64 rows. Status: complete source draft, not auditioned.

First half uses c; second half uses g.

Ch1 kick/snare packets; Ch2 TechBass; Ch3 Leader claims; Ch4 filter, delayed hats and alternating control chirps.

## Effects used here

Cxx sets channel volume immediately, from `00` silence to `40` maximum. Each written note includes its instrument; its default volume is restored at the next trigger before any row effect.
EC3 cuts that channel at tick 03 within the row; the next written trigger restores the sample default. There are no inherited slides or vibrato settings.
ED1 delays the written hat trigger until tick `01`. This is a short timing displacement within the row, not an XM note delay.

| Row | Ch1 | Ch2 | Ch3 | Ch4 |
| --- | --- | --- | --- | --- |
| 00 | C-4 01 C28 | D-4 04 --- | --- -- C00 | C-4 08 C1C |
| 01 | --- -- --- | --- -- --- | D-4 05 C24 | --- -- --- |
| 02 | --- -- --- | A-4 04 EC3 | --- -- --- | --- -- --- |
| 03 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 04 | C-4 02 C27 | --- -- --- | F#4 05 EC3 | C-4 03 C38 |
| 05 | --- -- --- | D-4 04 EC3 | --- -- --- | --- -- --- |
| 06 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 08 | C-4 01 C28 | F#4 04 EC3 | A-4 05 C24 | --- -- --- |
| 10 | --- -- --- | A-4 04 --- | --- -- --- | C-4 03 ED1 |
| 11 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 12 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 13 | --- -- --- | D-5 04 EC3 | G#4 05 C20 | --- -- --- |
| 14 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 15 | --- -- --- | D-4 04 --- | --- -- --- | C-4 07 C22 |
| 16 | C-4 01 C28 | D-4 04 --- | --- -- --- | --- -- --- |
| 18 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 19 | --- -- --- | A-4 04 EC3 | F#4 05 EC3 | --- -- --- |
| 20 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 22 | --- -- --- | D-4 04 EC3 | --- -- --- | C-4 03 C40 |
| 24 | C-4 01 C28 | F#4 04 EC3 | E-4 05 C20 | --- -- --- |
| 26 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 27 | --- -- --- | A-4 04 --- | --- -- --- | --- -- --- |
| 28 | C-4 02 C27 | --- -- --- | D-4 05 C24 | --- -- --- |
| 30 | --- -- --- | D-5 04 EC3 | --- -- --- | C-4 03 C40 |
| 31 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |
| 32 | C-4 01 C28 | D-4 04 --- | A-4 05 C24 | D-3 06 C20 |
| 34 | --- -- --- | A-4 04 EC3 | --- -- --- | --- -- --- |
| 35 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 36 | C-4 02 C27 | --- -- --- | --- -- --- | C-4 03 C38 |
| 37 | --- -- --- | D-4 04 EC3 | G#4 05 EC3 | --- -- --- |
| 38 | --- -- --- | --- -- --- | --- -- --- | C-4 03 C40 |
| 40 | C-4 01 C28 | F#4 04 EC3 | --- -- --- | --- -- --- |
| 42 | --- -- --- | A-4 04 --- | F#4 05 C24 | C-4 03 ED1 |
| 43 | C-4 01 C22 | --- -- --- | --- -- --- | --- -- --- |
| 44 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 45 | --- -- --- | D-5 04 EC3 | --- -- --- | --- -- --- |
| 46 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 C40 |
| 47 | --- -- --- | D-4 04 --- | --- -- --- | C-4 07 C22 |
| 48 | C-4 01 C28 | D-4 04 --- | --- -- --- | --- -- --- |
| 50 | C-4 01 C22 | --- -- --- | E-4 05 C20 | C-4 03 ED1 |
| 51 | --- -- --- | A-4 04 EC3 | --- -- --- | --- -- --- |
| 52 | C-4 02 C27 | --- -- --- | --- -- --- | --- -- --- |
| 54 | --- -- --- | D-4 04 EC3 | --- -- --- | C-4 03 C40 |
| 55 | --- -- --- | --- -- --- | C#4 05 EC3 | --- -- --- |
| 56 | C-4 01 C28 | F#4 04 EC3 | --- -- --- | --- -- --- |
| 58 | C-4 01 C22 | --- -- --- | --- -- --- | C-4 03 ED1 |
| 59 | --- -- --- | A-4 04 --- | --- -- --- | --- -- --- |
| 60 | C-4 02 C27 | --- -- --- | A-3 05 C20 | --- -- --- |
| 62 | --- -- --- | D-5 04 EC3 | --- -- --- | C-4 03 C40 |
| 63 | --- -- --- | --- -- --- | --- -- --- | C-4 09 C1C |

## Audition criteria

- Listen to this entire pattern inside its complete group, then at every order-list occurrence. Check the melodic breath between the two halves, the bass response and the deliberate percussion handoffs.
- Check each EC cut and each percussion replacement of a pitched voice for a musically acceptable edge. Notes are single-voice events; tails can be deliberately interrupted on the same channel.
- Check balance in normal stereo and mono. The bass must remain a coherent line beneath the melodic signal, and short hats/ticks must remain audible without taking over.
- Check the five-tick articulation, especially one-tick hat delays: it should sound deliberate, not like misplaced notes. Audition the saturated kick and snare quietly as well as at normal level.
