# Sample set — Bus Contention

Status: provisional analytical selection from the actual supplied archives. Sample audition takes place after composition, as requested. The source bytes are not edited.

These are headerless raw sample files, interpreted provisionally as signed 8-bit mono PCM. There is no stored playback rate, note, finetune or loop metadata in these files. Confirm interpretation in the compiled import. All instrument finetunes are `00`; no pitch correction is silently applied.

| ID | Source | Role | Bytes (hex) | Peak | RMS quarters | DC | Rails % | Default volume |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | ST-01/BassDrum4 | kick | 0DAC | 128 | 84.92 / 10.35 / 8.26 / 6.46 | -2.69 | 7.06 | `28` |
| 02 | ST-02/Snare8 | snare | 0BB8 | 128 | 89.32 / 36.37 / 7.12 / 3.70 | -2.17 | 4.03 | `27` |
| 03 | ST-01/CloseHiHat | hat | 04B0 | 34 | 11.34 / 3.25 / 0.67 / 0.22 | 0.02 | 0.00 | `40` |
| 04 | ST-01/TechBass | bass | 13EC | 76 | 27.07 / 20.60 / 6.93 / 2.33 | -0.07 | 0.00 | `3B` |
| 05 | ST-01/Leader | lead | 0D48 | 127 | 48.66 / 29.97 / 12.41 / 2.00 | -0.04 | 0.03 | `24` |
| 06 | ST-01/KorgFilter | stab | 0D48 | 86 | 22.33 / 26.26 / 25.01 / 24.31 | -0.06 | 0.00 | `20` |
| 07 | ST-01/SynClaves | tick | 03E8 | 127 | 46.12 / 11.81 / 4.26 / 1.51 | -0.16 | 0.10 | `22` |
| 08 | ST-02/Cymbal2 | cymbal | 0CE4 | 128 | 68.83 / 40.59 / 10.75 / 3.39 | -0.25 | 1.55 | `1C` |
| 09 | ST-01/Blubzing | tick2 | 0514 | 127 | 42.96 / 23.38 / 10.47 / 9.23 | -0.11 | 0.08 | `1C` |

Signal measurements use decimal sample units; a signed sample lies from -128 to +127. RMS quarters are chronological, equal-duration portions of the unchanged file. Rail percentage counts samples exactly at -128 or +127; it is evidence of saturation risk, not proof of audible clipping. Volumes and IDs are hexadecimal.

- `01` ST-01/BassDrum4: A sharp saturated source selected deliberately for attack; lower default tempers its high peak.
- `02` ST-02/Snare8: Punchy clipped transient and quickly falling body; harshness remains an audition risk.
- `03` ST-01/CloseHiHat: Quiet source can articulate the fast grid without an excessively loud noise bed.
- `04` ST-01/TechBass: Low harmonic series with a strong upper component; short packets suit its finite decay.
- `05` ST-01/Leader: Short claims with enough space for another channel to answer.
- `06` ST-01/KorgFilter: Finite bright request marker.
- `07` ST-01/SynClaves: Dry control tick.
- `08` ST-02/Cymbal2: Only transfer peaks and the final grant need a broad accent.
- `09` ST-01/Blubzing: Irregular spectrum makes it an unpitched packet chirp, never a tonal lead.

## Suitability, register and balance

Every pitched part is a single monophonic line; there are no chord samples or arpeggiator effects. Pitched sample spectra are broadly consistent with C-related harmonic material; this is provisional suitability evidence, not a by-ear confirmation that every source is an ideal single note. Inharmonic bells and attack noise should not be mistaken for deliberately layered chords.

Default volumes balance source RMS, peak and role. Percussion with large peaks is attenuated; the quiet CloseHiHat, when selected, uses its full source level. Per-row accents remain explicit in the tables. A lower default cannot undo clipping already present in source audio.

DXBass was excluded because its source has a very large DC offset. CowBell was excluded from these sets because of substantial rail occupancy and DC. Where a saturated kick/snare is selected, its grit is a deliberate provisional timbral choice and is identified above. No reverse or ping-pong behaviour is used.

All selected envelopes are used as finite events. No sustained pad role is required; see `loops.md` for loopability decisions and the KorgFilter seam diagnostic. The exact written pitch subsets and provisional source-root estimates are in `ranges.md`.

## Sample audition criteria — after composition

- Solo each instrument at every actual trigger pitch in `ranges.md`, using its metadata volume first. Confirm signed PCM interpretation, note identity, register, attack quality and tail behaviour.
- Compare bass and main voice on the same named tonic and fifth; allow their planned octave separation, then listen for unintended detuning or beating. Keep finetune zero unless the brief is explicitly changed.
- Check the pitched samples are perceived as single notes. If a source sounds like a fixed chord, report that source and exact trigger; do not approve it merely because the spectrum looked harmonic.
- Check low sample endings and every gate for clicks. Evaluate noisy percussion tails at both normal and quiet monitoring levels. Check deliberately saturated sources for useful grit versus objectionable harshness.
- Check kick/bass balance, main-voice intelligibility and hat/tick audibility in the complete ensemble and in mono. Compare the initial group with the densest group before deciding defaults.
- Preserve accepted by-ear sample volumes, loop changes, finetune and row edits in the actual auditioned project. Return that exact project with notes so the source can be reconciled.

Piece-specific check: Check the five-tick articulation, especially one-tick hat delays: it should sound deliberate, not like misplaced notes. Audition the saturated kick and snare quietly as well as at normal level.
